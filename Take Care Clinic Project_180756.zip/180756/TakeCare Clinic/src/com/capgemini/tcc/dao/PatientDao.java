package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.tcc.Exception.PatientException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.util.DBUtil;

public class PatientDao implements IPatientDao {
	Connection conn;
	Logger logg;

	public PatientDao() {

		logg = Logger.getRootLogger();

	}

	public int generatepurchaseId() {
		logg.info("In generatePatientId method ");
		int pId = 0;
		String SQL = "select patient_id_seq.nextval from dual";
		conn = DBUtil.getConnection();
		try {
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(SQL);
			resultSet.next();
			pId = resultSet.getInt(1);
			logg.info("Got patientId " + pId);
		} catch (SQLException e) {

			logg.error(e.getMessage());
			System.err.println(e.getMessage());

		}
		logg.info("Completed Method patientId");
		return pId;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		// TODO Auto-generated method stub
		PatientBean p = new PatientBean();
		try {
			conn = DBUtil.getConnection();
			PreparedStatement ps2 = conn
					.prepareStatement(QueryMapper.SEARCHQUERY);

			ps2.setInt(1, patientId);

			ResultSet resultSet = ps2.executeQuery();
			while (resultSet.next()) {
				p.setPatient_Id(resultSet.getInt(1));
				p.setPatient_Name(resultSet.getString(2));
				p.setAge(resultSet.getInt(3));
				p.setPhone(resultSet.getString(4));
				p.setDescription(resultSet.getString(5));
				p.setConsultant_date(resultSet.getDate(6).toLocalDate());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}

	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		// TODO Auto-generated method stub

		logg.info("Add detail");
		logg.info("Input :" + patient);
		conn = DBUtil.getConnection();
		int patientId = generatepurchaseId();
		try {
			PreparedStatement ps = conn
					.prepareStatement(QueryMapper.INSERTQUERY);
			ps.setInt(1, patientId);
			ps.setString(2, patient.getPatient_Name());
			ps.setInt(3, patient.getAge());
			ps.setString(4, patient.getPhone());
			ps.setString(5, patient.getDescription());
			java.sql.Date date = Date.valueOf(patient.getConsultant_date());
			ps.setDate(6, date);
			ps.executeUpdate();
			logg.info("successfully Insert and id is = " + patientId);
			conn.commit();
		} catch (SQLException e) {
			logg.error(e.getMessage());
			e.printStackTrace();

		}
		return patientId;
	}
}
