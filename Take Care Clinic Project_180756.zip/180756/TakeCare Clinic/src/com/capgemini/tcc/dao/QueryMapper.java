package com.capgemini.tcc.dao;

public class QueryMapper {
	//Queries 

	
	public static final String SEARCHQUERY="select * from patient where patient_id=?";	
	public static final String INSERTQUERY="insert into patient values(?,?,?,?,?,?)";
	
}
