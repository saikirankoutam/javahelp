package com.cg.service;

import com.cg.beans.DemandDraft;

public interface IDemandDraftService {
  int addDemandDraftDetails(DemandDraft demandDraft);
  DemandDraft getDemandDraftDetails(int transactionId);
  
}
