package com.cg.service;

import com.cg.beans.DemandDraft;

public class DemandDraftService implements IDemandDraftService{

	public DemandDraftService()  {
		// 
	}

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

}
