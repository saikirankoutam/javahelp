package com.cg.dao;

import com.cg.beans.DemandDraft;
import com.cg.exception.DemandException;

public interface IDemandDraftDAO {
int addDemandDraftDetails(DemandDraft demandDraft) throws DemandException;
DemandDraft getDemandDraftDetails(int transactionId) throws DemandException;
}
