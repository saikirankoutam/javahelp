package com.cg.dao;

public interface QueryMapper {
	public  static final String TRANSACTIONSEQ=" Select Transaction_Id_seq.currval from dual";
	public static  final String INSERTQUERY="insert into demand_draft  values(?, ?, ?,?,?)";
}
