package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.beans.DemandDraft;
import com.cg.exception.DemandException;
import com.cg.util.DBUtil;

public class DemandDraftDAO implements IDemandDraftDAO {
Connection con;
private int id;
private PreparedStatement PreparedStatement;
 
public int generateTransactionId() throws DemandException{
	int generateTransactionId=0;
	String SQL="select Transaction_id_seq.nextval from dual";
	
	try {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(SQL);
		if(rs.next())
		{
			id=rs.getInt(generateTransactionId);
		}
	} catch (SQLException e) {
		
	throw new DemandException(e.getMessage());
	}
	return generateTransactionId;
}
	

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws DemandException {
int transaction_id=generateTransactionId();
con=DBUtil.getConnection();
try {
	PreparedStatement=con.prepareStatement(QueryMapper.INSERTQUERY);
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		return 0;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

}
