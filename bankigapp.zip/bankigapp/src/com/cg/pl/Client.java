package com.cg.pl;

public class Client {

	public Client() {
		// TODO Auto-generated constructor stub
	}

}
