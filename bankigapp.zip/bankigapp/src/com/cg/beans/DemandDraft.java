package com.cg.beans;

import java.time.LocalDate;

public class DemandDraft {
private int transaction_id;
private String customer_name;
private String in_favour_of;
private int phone_number;
private LocalDate date_of_tranaction;
private double dd_amount;
private double dd_commission;
	public DemandDraft() {
	super();
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getIn_favour_of() {
		return in_favour_of;
	}
	public void setIn_favour_of(String in_favour_of) {
		this.in_favour_of = in_favour_of;
	}
	public int getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(int phone_number) {
		this.phone_number = phone_number;
	}
	public LocalDate getDate_of_tranaction() {
		return date_of_tranaction;
	}
	public void setDate_of_tranaction(LocalDate date_of_tranaction) {
		this.date_of_tranaction = date_of_tranaction;
	}
	public double getDd_amount() {
		return dd_amount;
	}
	public void setDd_amount(double dd_amount) {
		this.dd_amount = dd_amount;
	}
	public double getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(double dd_commission) {
		this.dd_commission = dd_commission;
	}
	public DemandDraft(int transaction_id, String customer_name,
			String in_favour_of, int phone_number,
			LocalDate date_of_tranaction, double dd_amount, double dd_commission) {
		super();
		this.transaction_id = transaction_id;
		this.customer_name = customer_name;
		this.in_favour_of = in_favour_of;
		this.phone_number = phone_number;
		this.date_of_tranaction = date_of_tranaction;
		this.dd_amount = dd_amount;
		this.dd_commission = dd_commission;
	}
	@Override
	public String toString() {
		return "DemandDraft [transaction_id=" + transaction_id
				+ ", customer_name=" + customer_name + ", in_favour_of="
				+ in_favour_of + ", phone_number=" + phone_number
				+ ", date_of_tranaction=" + date_of_tranaction + ", dd_amount="
				+ dd_amount + ", dd_commission=" + dd_commission + "]";
	}
	

}
