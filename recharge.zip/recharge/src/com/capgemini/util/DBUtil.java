package com.capgemini.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBUtil {


	private static Connection con;
		public static Connection getConnection() {
	
	if (con == null) {
		try {
			FileReader reader = new FileReader("resource/jdbc.properties");
			Properties properties = new Properties();
			properties.load(reader);
			Class.forName(properties.getProperty("driver"));
			con = DriverManager.getConnection(
					properties.getProperty("url"),
					properties.getProperty("userName"),
					properties.getProperty("password"));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	return con;
		}
	
/*public static void main(String[] args) {
	System.out.println(DBUtil.getConnection());
	System.out.println("//////////////////////");
	System.out.println(DBUtil.getConnection());
}
*/
}
