package com.capgemini.service;

import javax.security.auth.login.AccountException;

import com.capgemini.beans.Account;

public interface AccountService {
public Account getAccountDetails(String accountId)throws AccountException;
int rechargeAccount(String accountId,double rechargeAmount) throws AccountException;
}
