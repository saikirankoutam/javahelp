package com.capgemini.service;

import java.sql.Connection;

import com.capgemini.beans.Account;

public class AccountServiceImpl implements AccountService{
	Connection con;
	

	public AccountServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Account getAccountDetails(String accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int rechargeAccount(String accountId, double rechargeAmount) {
		// TODO Auto-generated method stub
		return 0;
	}

}
