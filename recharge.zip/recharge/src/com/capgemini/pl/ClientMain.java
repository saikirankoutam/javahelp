package com.capgemini.pl;

public class ClientMain {

	public ClientMain() {
		// TODO Auto-generated constructor stub
	}

}
