package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.security.auth.login.AccountException;

import com.capgemini.beans.Account;
import com.capgemini.util.DBUtil;

public class AccountDaoImpl implements AccountDao{
Connection con;
	int accountBalance=0;
	@Override
	public Account getAccountDetails(String accountId) throws AccountException {
		Account ac=new Account();
		con=DBUtil.getConnection();
		try {
			PreparedStatement preparedStatement=con.prepareStatement(QuerryMapper.SEARCH);
			preparedStatement.setString(1, accountId);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()){
				ac.setAccountBalance(rs.getDouble(1));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AccountException(e.getMessage());
		}
		return ac;
	}

	@Override
	public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException {
	Account ac=new Account();
	con=DBUtil.getConnection();
	try {
		PreparedStatement preparedStatement=con.prepareStatement(QuerryMapper.recharge);
		preparedStatement.setString(1, accountId);
		preparedStatement.setDouble(2, rechargeAmount);
		ResultSet rs=preparedStatement.executeQuery();
		while(rs.next()){
			ac.setAccountId(accountId);
			ac.setAccountType(rs.getString(2));
			ac.setCustomerName(rs.getString(3));
			ac.setAccountBalance(rs.getDouble(4));
			
		}
	} catch (SQLException e) {
		
		throw new AccountException(e.getMessage());
		
	}
	if(ac==null){
		System.out.println("cannot exit that gien id");
	}
	double newAccBalance=accountBalance+rechargeAmount;
	try {
		PreparedStatement preparedStatement=con.prepareStatement(QuerryMapper.update);
		preparedStatement.setDouble(1, newAccBalance);
		preparedStatement.setString(2, accountId);
		preparedStatement.executeUpdate();		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
		return 0;
	}

}
