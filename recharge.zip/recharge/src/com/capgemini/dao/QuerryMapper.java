package com.capgemini.dao;

public interface QuerryMapper {
public static final String SEARCH="select account_balance from accountmob where account_id=?";
public static final String recharge=" Select account_id,account_type,Customer_name,account_balance from accountmob where account_id=?";

public static final String update = "update accountmob set account_balance=? where account_id=?";
}
