package com.capgemini.dao;

import javax.security.auth.login.AccountException;

import com.capgemini.beans.Account;

public interface AccountDao {
public Account getAccountDetails(String accountId)throws AccountException ;
public int rechargeAccount(String accountId,double rechargeAmount)throws AccountException;
}
