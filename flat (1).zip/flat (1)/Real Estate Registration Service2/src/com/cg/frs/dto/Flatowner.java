package com.cg.frs.dto;

public class Flatowner {
	
private int Owner_id;
private String Ownername;
private String Mobile;
public int getOwner_id() {
	return Owner_id;
}
public void setOwner_id(int owner_id) {
	Owner_id = owner_id;
}
public String getOwnername() {
	return Ownername;
}
public void setOwnername(String ownername) {
	Ownername = ownername;
}
public String getMobile() {
	return Mobile;
}
public void setMobile(String mobile) {
	Mobile = mobile;
}


	
}
