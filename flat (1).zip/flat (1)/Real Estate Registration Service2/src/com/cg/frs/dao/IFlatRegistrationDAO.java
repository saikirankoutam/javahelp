package com.cg.frs.dao;

import java.util.List;

import com.cg.frs.dto.FlatRegistrationDTO;




public interface IFlatRegistrationDAO {

public List<Integer> getOwnerId();
public int generateflatId();
public int RegisterFlat(FlatRegistrationDTO flatregisterdto);
}
