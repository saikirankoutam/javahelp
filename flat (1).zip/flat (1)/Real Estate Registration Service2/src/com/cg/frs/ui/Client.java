package com.cg.frs.ui;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RegistrationException;
import com.cg.frs.service.IFlatRegistrationService;
import com.cg.frs.service.IFlatRegistrationServiceImpl;

public class Client {
 public static void main(String[] args) {
	IFlatRegistrationService service=new IFlatRegistrationServiceImpl(); 
	Scanner scanner=new Scanner(System.in);
	System.out.println("********Real Estate Registration  Service*******");
	System.out.println();
	System.out.println("1. Register Flat");
	System.out.println("2. Exit");
	System.out.println("Please Enter Your Choice");
	int choice=scanner.nextInt();
	switch(choice)
	{
	case 1:
	
		System.out.println("Existing owner ids are:- "+ service.getOwnerId());
		System.out.println();
		System.out.println("Please enter your owner id from above list:");
		int ownerid=scanner.nextInt();
		
		System.out.println("Select Flat Type");
		int flattype=scanner.nextInt();
		System.out.println("Enter Flat area in square ft");
		int area=scanner.nextInt();
		System.out.println("Enter desired rent amount");
		int rent=scanner.nextInt();
		System.out.println("Enter desired deposit amount");
		int depositamount=scanner.nextInt();
	 
	FlatRegistrationDTO regobj= new FlatRegistrationDTO(ownerid,flattype,area,rent,depositamount);
	try {
		if (service.validateRegisterDetails(regobj)) {
			//service.RegisterFlat(regobj);
			System.out.println("Registered Successfully with RegisteredId : "+ service.RegisterFlat(regobj));
		}
	} catch (RegistrationException e) {
		System.err.println(e.getMessage());
	}
		
      
	     break;
      case 2:	
		System.exit(0);
	break;
	default:
		System.out.println("Invalid Choice");
		break;
	
	}
	 
}
	
	
	
	
}
