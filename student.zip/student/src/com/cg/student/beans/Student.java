package com.cg.student.beans;

import java.time.LocalDate;

public class Student {

	private int studentId;
	private String stdName;
	private long phoneNumber;
	private LocalDate dob;
	private String standard;
	private int age;
	public Student() {
		super();
		
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Student(int studentId, String stdName, long phoneNumber,
			LocalDate dob, String standard, int age) {
		super();
		this.studentId = studentId;
		this.stdName = stdName;
		this.phoneNumber = phoneNumber;
		this.dob = dob;
		this.standard = standard;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", stdName=" + stdName
				+ ", phoneNumber=" + phoneNumber + ", dob=" + dob
				+ ", standard=" + standard + ", age=" + age + "]";
	}

}
