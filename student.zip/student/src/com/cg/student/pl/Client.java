package com.cg.student.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import com.cg.student.beans.Student;
import com.cg.student.exceptions.StudentException;
import com.cg.student.service.StudentService;
import com.cg.student.service.StudentServiceImpl;

public class Client {
	static StudentService service=new StudentServiceImpl();
	public static void main(String[] args){
		//int choice=0;
		try(Scanner sc=new Scanner(System.in)){
			do
			{
				System.out.println("*********************************");
				System.out.println("||1.add student details        ||");
				System.out.println("||2.delete student details     ||");
				System.out.println("||3.search by id               ||");
				System.out.println("||4.get all student details    ||");
				System.out.println("||5.update phone details       ||");
				System.out.println("||6.exit                       ||");
				System.out.println("*********************************");
				System.out.println("choose one");
				int choice=sc.nextInt();
				switch(choice){
				case 1:
					System.out.println("enter student name");
					String name=sc.next();
					System.out.println("enter phone number");
					long phone=sc.nextLong();
					System.out.println("enter date of birth");
					String ordDateStr = sc.next();
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					LocalDate ordDate = LocalDate.parse(ordDateStr,  format);
					System.out.println("enter student standard");
					String stand=sc.next();
					System.out.println("enter student age");
					int age=sc.nextInt();
					Student stud=new Student(0,name,phone,ordDate,stand,age);
					
					try {
						if(service.isvalidEnquiry(stud)){
						service.addStudent(stud);
						System.out.println("details added succesfully"+service.generateStudentId());}
					} catch (StudentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case 2:
					System.out.println("enter student is to delete");
					int stid=sc.nextInt();
					try {
						int stid1 =service.deleteStudentById(stid);
						if(stid1==0){
							System.out.println("record not deleted");
						}else 
						System.out.println("details deleted successfully");
					} catch (StudentException e) {
					System.out.println(e.getMessage());
						
					}break;
				case 3:
					System.out.println(" enter student id to search");
					int sd=sc.nextInt();
					try {
						Student st=	service.getStudentById(sd);
						//System.out.println(st);
						if(st!=null){
						System.out.println("student id is "+st.getStudentId());
						System.out.println("student name is"+st.getStdName());
						System.out.println("student phone number is"+st.getPhoneNumber());
						System.out.println("student dob is"+st.getDob());
						System.out.println("student standard is"+st.getStandard());
						System.out.println("student age is "+st.getAge());}
						else
				System.out.println("student id not exit ");
					} catch (StudentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}break;
				case 4:
					try {
						List<Student>list=service.getAllStudent();
						/*if(list.size()==0){
							System.out.println("No product available");
						}*/
						//else{
						for(Student p1:list){
							System.out.println(p1);
						}}
					catch( StudentException e){
						System.out.println(e.getMessage());
					}break;
				case 5:
					System.out.println("enter student id to update");
					int d=sc.nextInt();
					System.out.println("enter phone number to update");
					long ph=sc.nextLong();
					try {
						int r=service.updatePhoneNumber(d, ph);
						if(r==0){
							System.out.println("record not updated");
						}else 
						
						System.out.println("updated sucess");
					} catch (StudentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}break;
				case 6:System.out.println("thanks you ");
				System.exit(0);

				break;
				default:

					System.err.println("enter valid data");break;
				}		

			}while(true);
		}
	}
}



