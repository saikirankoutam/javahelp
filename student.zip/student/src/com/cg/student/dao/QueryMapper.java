package com.cg.student.dao;

public interface QueryMapper {
	public static final String INSERTQUERY="insert into student values(sud_seq.nextval,?,?,?,?,?)";
	public  static final String studentsequence=" Select sud_seq.currval from dual";
public static final String deletequery="delete student where studentid=?";
public static final String searchId="select * from student where studentid=?";
public static final String allStudent="select * from student";
public static final String updatequery="update student set phonenumber=? where studentid=?";
}
