
public class Example {

	public Example() {
		// TODO Auto-generated constructor stub
	}

}
/*EmployeeDAO dao;

public EmployeeServiceImpl() {

dao=new EmployeeDAOImpl();

}

@Override

public int addEmployee(Employee obj) throws EmployeeException {

// TODO Auto-generated method stub

return 0;

}



@Override

public Employee getEmployeeById(int empId) throws EmployeeException {

// TODO Auto-generated method stub

return null;

}



@Override

public ArrayList<Employee> getAllEmployee() throws EmployeeException {

// TODO Auto-generated method stub

return dao.getAllEmployee();

}



@Override

public boolean validateName(String name) {

// TODO Auto-generated method stub

String pattern= "[A-Z]{1}[a-z]{2,}";

if(Pattern.matches(name, pattern))

 return true;

else

return false;

}



@Override

public boolean validateSalary(int salary) {

// TODO Auto-generated method stub

String pattern= "[0-9]{4,6}";

if (Pattern.matches(salary+"", pattern))

return true;

else

 return false;

}



@Override

public boolean validateId(int empId) {

// TODO Auto-generated method stub

String pattern= "[0-9]{3}";

if(Pattern.matches(empId+"", pattern))

return true;

else

 return false;

}



@Override

public boolean validateDate(String date) {

// TODO Auto-generated method stub

DateTimeFormatter format= DateTimeFormatter.ofPattern("dd/MM/yyyy");

LocalDate bdate=LocalDate.parse(date, format);

if(bdate!=null)

 return true;

else

return false;

}

*/