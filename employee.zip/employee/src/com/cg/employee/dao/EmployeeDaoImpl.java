package com.cg.employee.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	Connection con;
	PreparedStatement preparedStatement;
	public EmployeeDaoImpl() {
		con=DBUtil.getConnection();
	}

	@Override
	public int addEmployee(Employee obj) throws EmployeeException{

		int eid=0;
		try {
			//String query="insert into CRMPune values(eId_CRM.NEXTVAL,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(Mapper.query);
			pstmt.setString(1, obj.getEmpName());
			pstmt.setInt(2, obj.getEmpSal());
			java.sql.Date date=Date.valueOf(obj.getEdate());
			pstmt.setDate(3, date);
			int row=pstmt.executeUpdate();
			if(row>0){
				eid=getEmployeeId();

			}
		}catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
			// TODO: handle exception
		}

		return eid;
	}


	public int getEmployeeId() throws EmployeeException{
		int id=0;
		String qry= "SELECT eId_CRM.CURRVAL FROM DUAL";
		try {
			Statement stmt= con.createStatement();
			ResultSet rs= stmt.executeQuery(qry);
			if(rs.next())
			{
				id=rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
			
		}
		return id;
	}
	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException{

		ArrayList<Employee>list=new ArrayList<Employee>();
		String query="select * from CRMPune";
		try{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int salary=rs.getInt(3);
				LocalDate date=rs.getDate(4).toLocalDate();
				Employee emp=new Employee(id,name,salary,date);
				list.add(emp);
			}

		}catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}

		return list;
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException{


		Employee emp= null;
		String query="select * from CRMPune where empId=?";
		try {
			PreparedStatement pstmt= con.prepareStatement(query);
			pstmt.setInt(1, empId);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				int id = rs.getInt(1);
				String name= rs.getString(2);
				int salary = rs.getInt(3);
				LocalDate date=rs.getDate(4).toLocalDate();
				emp= new Employee(id, name, salary,date);
			} 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
		return emp;
	}

	@Override
	public int deleteEmployeeById(int empId) throws EmployeeException {
	
		String Query="delete  from CRMPune where empid=?";
		
			int ps=0;
			
		
		try {
			preparedStatement=con.prepareStatement(Query);
			preparedStatement.setInt(1, empId);
		     ps=	preparedStatement.executeUpdate();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ps;
	}

	@Override
	public int updateSalary(int empId, int empSal) throws EmployeeException {
		String Query="update CRMPune set empSal=? where empId=?";
		try {
			PreparedStatement pstmt= con.prepareStatement(Query);
			pstmt.setInt(1, empSal);
			pstmt.setInt(2, empId);
			int d=pstmt.executeUpdate();
			return d;
		} catch (SQLException e) {
			
			throw new EmployeeException(e.getMessage());
		}
		
		
	}	 



}
