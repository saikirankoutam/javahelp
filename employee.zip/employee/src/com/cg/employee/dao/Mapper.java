package com.cg.employee.dao;

public interface Mapper {
	String query="insert into CRMPune values(eId_CRM.NEXTVAL,?,?,?)";
}
