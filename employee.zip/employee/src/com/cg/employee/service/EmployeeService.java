package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {
public int addEmployee(Employee obj)throws EmployeeException;
//public Employee getEmployeeBy(Employee obj) throws EmployeeException;

public ArrayList<Employee>getAllEmployee() throws EmployeeException;
public boolean validateName(String NAME);
public boolean validateSalary(int Salary);
public boolean validateId(int Id);
public boolean validateAge(int Age);
public Employee getEmployeeById(int empId) throws EmployeeException;
public int deleteEmployeeById(int id) throws EmployeeException;
public int updateSalary(int empId,int empSal) throws EmployeeException;
}
