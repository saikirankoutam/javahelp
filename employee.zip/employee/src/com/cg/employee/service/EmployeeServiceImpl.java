package com.cg.employee.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;


public class EmployeeServiceImpl implements EmployeeService {
EmployeeDao dao;

public EmployeeServiceImpl(){
	dao=new EmployeeDaoImpl();
	
}
	@Override
	public int addEmployee(Employee obj) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.addEmployee(obj);
	}


	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public boolean validateName(String NAME) {
		String pattern= "[A-Z]{1}[a-z]{2,}";

		if(Pattern.matches( pattern,NAME)){

		 return true;
		}
		else

		return false;

		
	}

	@Override
	public boolean validateSalary(int Salary) {
		// TODO Auto-generated method stub
		String pattern= "[0-9]{4,}";

		if (Pattern.matches( pattern,Salary+"")){

		return true;
		}
		else

		return false;
	}

	@Override
	public boolean validateId(int Id) {
		// TODO Auto-generated method stub
		String pattern= "[0-9]{3}";

		if(Pattern.matches( pattern,Id+"")){

		return true;
		}
		else

		return false;
	}
	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {
		
		return dao.getEmployeeById(empId);
	}
	@Override
	public int deleteEmployeeById(int empId) throws EmployeeException {
	
		return dao.deleteEmployeeById(empId);
	}
	@Override
	public int updateSalary(int empId, int empSal) throws EmployeeException {
		return dao.updateSalary(empId, empSal);
	}
	@Override
	public boolean validateAge(int Age) {
		String pattern="[0-9]{1}";
		if(Pattern.matches(pattern,Age+""))
		{
			return true;
		}else
		return false;
	}
}
	